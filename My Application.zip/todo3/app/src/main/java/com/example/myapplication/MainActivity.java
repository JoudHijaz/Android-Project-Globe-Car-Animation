package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView cloudFast, cloudSlow, sun, trafficLight, car, rock, earth;
    private Handler trafficLightHandler = new Handler();
    private ObjectAnimator carRotation;
    private boolean rockAnimationTriggered = false;

    private int state = 0; // 0 = red, 1 = yellow, 2 = green

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize ImageViews
        cloudFast = findViewById(R.id.cloud_fast);
        cloudSlow = findViewById(R.id.cloud_slow);
        sun = findViewById(R.id.sun);
        trafficLight = findViewById(R.id.traffic_light);
        car = findViewById(R.id.car);
        rock = findViewById(R.id.rock);
        earth = findViewById(R.id.earth);

        // Start cloud and sun animations
        Animation animFast = AnimationUtils.loadAnimation(this, R.anim.cloud_fast);
        Animation animSlow = AnimationUtils.loadAnimation(this, R.anim.cloud_slow);
        Animation sunAnimation = AnimationUtils.loadAnimation(this, R.anim.sun);

        if (animFast != null && animSlow != null && sunAnimation != null) {
            cloudFast.startAnimation(animFast);
            cloudSlow.startAnimation(animSlow);
            sun.startAnimation(sunAnimation);
        }

        // Initialize car rotation
        startCarAnimation();

        // Start traffic light sequence
        startTrafficLightSequence();
    }

    private void startCarAnimation() {
        // Calculate the pivot points dynamically after layout has been done
        car.post(() -> {
            float earthCenterX = earth.getX() + earth.getWidth() / 2;
            float earthCenterY = earth.getY() + earth.getHeight() / 2;

            // Coordinates of the car's center
            float carCenterX = car.getX() + car.getWidth() / 2;
            float carCenterY = car.getY() + car.getHeight() / 2;

            // Calculate pivot X and Y relative to the car's position
            float pivotX = earthCenterX - carCenterX + car.getWidth() / 2;
            float pivotY = earthCenterY - carCenterY + car.getHeight() / 2;

            // Applying rotation using ObjectAnimator
            carRotation = ObjectAnimator.ofFloat(car, "rotation", 0f, 720f);
            car.setPivotX(pivotX);
            car.setPivotY(pivotY);
            carRotation.setDuration(10000);
            carRotation.setInterpolator(new LinearInterpolator());
            carRotation.setRepeatCount(ObjectAnimator.INFINITE);
            carRotation.addUpdateListener(animation -> {
                // Check if the car's rotation is at the rock's position
                if (((Float) animation.getAnimatedValue()) % 360 > 100 && ((Float) animation.getAnimatedValue()) % 360 < 120) {
                    triggerRockAnimation();

                }
            });


        });
    }

    private void triggerRockAnimation() {
        if (!rockAnimationTriggered) {
            Animation rockAnim = AnimationUtils.loadAnimation(this, R.anim.rock);
            rock.startAnimation(rockAnim);
            rockAnimationTriggered = true;
        }
    }


    private void startTrafficLightSequence() {
        Runnable trafficLightRunnable = new Runnable() {
            @Override
            public void run() {
                switch (state) {
                    case 0: // Red
                        if (trafficLight != null) {
                            trafficLight.setImageResource(R.drawable.red2);
                        }
                        if (carRotation != null && carRotation.isRunning()) {
                            carRotation.pause();
                        }
                        state = 1;
                        trafficLightHandler.postDelayed(this, 3000);
                        break;
                    case 1: // Yellow
                        if (trafficLight != null) {
                            trafficLight.setImageResource(R.drawable.yellow2);
                        }
                        state = 2;
                        trafficLightHandler.postDelayed(this, 2000);
                        break;
                    case 2: // Green
                        if (trafficLight != null) {
                            trafficLight.setImageResource(R.drawable.green2);
                        }
                        if (carRotation != null) {
                            carRotation.start();
                        }
                        state = 0;
                        trafficLightHandler.postDelayed(this, 5000);
                        break;
                }
            }
        };
        trafficLightHandler.postDelayed(trafficLightRunnable, 0);
    }


}
